package checkers;

/**
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
public enum MoveType {
    NONE, NORMAL, KILL
}
